NEXORA TECH — starter storefront

1. Open index.html in a browser to preview the website.
2. Before publishing, replace the placeholder email address (hello@nexoratech.example) with a real contact address you are authorized to use.
3. Add verified product listings, supplier information, shipping coverage, pricing, returns and privacy details before accepting orders.
4. This is a static catalogue/landing page. It does not process payments, store orders, or connect to suppliers.

Free hosting options to explore with a parent/guardian: Google Sites (rebuild the layout there) or GitHub Pages (host these static files; account eligibility and setup requirements may apply).
